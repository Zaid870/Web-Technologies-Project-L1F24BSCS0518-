
document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("theme-toggle-btn");
    const bodyElement = document.body;

    const savedTheme = localStorage.getItem("theme");

    if (savedTheme === "night") {
        bodyElement.classList.add("night-mode");

        if (toggleBtn) {
            toggleBtn.textContent = "☀️ Day Mode";
        }
    }

    if (toggleBtn) {
        toggleBtn.addEventListener("click", function () {
            bodyElement.classList.toggle("night-mode");

            if (bodyElement.classList.contains("night-mode")) {
                localStorage.setItem("theme", "night");
                toggleBtn.textContent = "☀️ Day Mode";
            } else {
                localStorage.setItem("theme", "day");
                toggleBtn.textContent = "🌙 Night Mode";
            }
        });
    }

    const slides = document.querySelectorAll(".slide");
    let currentIndex = 0;

    function nextSlide() {
        if (slides.length === 0) {
            return;
        }

        slides[currentIndex].classList.remove("active");

        currentIndex = (currentIndex + 1) % slides.length;

        slides[currentIndex].classList.add("active");
    }

    if (slides.length > 1) {
        setInterval(nextSlide, 3000);
    }
});
