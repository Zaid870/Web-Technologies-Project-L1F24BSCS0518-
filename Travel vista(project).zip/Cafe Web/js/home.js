// js/home.js - Advanced Typing Effect for Hero Section
document.addEventListener("DOMContentLoaded", function () {
    const heroTitle = document.querySelector("#hero-section h1");
    if (!heroTitle) return;

    const text = heroTitle.textContent;
    heroTitle.textContent = "";
    let i = 0;

    function typeWriter() {
        if (i < text.length) {
            heroTitle.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 50);
        }
    }

    // Thoda delay de kar animation start karein
    setTimeout(typeWriter, 300);
});