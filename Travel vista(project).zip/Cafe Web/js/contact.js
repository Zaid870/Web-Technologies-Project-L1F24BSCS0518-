// Small DOM Script: Theme Toggle and Form Feedback (Requirement for Page 6)
document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.getElementById('toggle-theme-btn');
    const body = document.body;

    // 1. Theme Toggle functionality (DOM manipulation)
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            body.classList.toggle('night-mode');
            if (body.classList.contains('night-mode')) {
                toggleBtn.textContent = 'Switch to Day Mode';
            } else {
                toggleBtn.textContent = 'Toggle Cafe Night Mode';
            }
        });
    }

    // 2. Simple Form Submission Feedback (DOM manipulation)
    const contactForm = document.getElementById('contactForm');
    const feedback = document.getElementById('form-feedback');

    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault(); // Prevents page reload on submit
            feedback.textContent = 'Thank you! Your message has been sent successfully.';
            feedback.style.color = '#27ae60';
            contactForm.reset();
        });
    }
});