# Web Technologies - Project (Travel Vista)

## Student Info
* **Name:** Muhammad Zaid Waseem
* **Roll Number:** BCSF20A001
* **Course:** Web Technologies (BSCS)

## Theme Chosen
* **Theme:** Travel Vista (Travel Agency Multi-page Website)

## Pages Included
1. **Home (`home.html`):** Overview, hero section with keyframe animation, and brand introduction.
2. **Destinations (`destinations.html`):** Popular global travel packages with Flexbox card grid layout.
3. **Media & Tours (`media.html`):** Video, audio guides, lists, and weekly group tours schedule table.
4. **Book Tour (`register.html`):** Comprehensive tour booking and registration form with HTML5 validation.
5. **Services (`services.html`):** Professional travel services card layout practicing Flexbox and hover transitions.
6. **Contact Us (`contact.html`):** Agency info, contact form, and JavaScript DOM night-mode toggle feature.

## AI Usage Log
As per project guidelines, AI tools were used as a tutor to brainstorm layout structure, explain CSS concepts, and debug syntax errors. All code has been reviewed, understood, and can be explained line-by-line during the viva.